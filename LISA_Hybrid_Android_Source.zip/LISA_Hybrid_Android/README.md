# LISA Hybrid Android starter

This is an **Android Studio source project**, not an installable APK yet. It is a first hybrid foundation for a native Android LISA app.

## What is included
- Native Android chat UI with a dark purple theme.
- Automatic online-first routing when internet is available; local fallback when online requests fail.
- Offline inference integration using MediaPipe LLM Inference (`.task` model file imported by the user).
- Android speech-to-text launch and text-to-speech replies.
- Optional Node.js online bridge. The provider API key stays on the server, not in the Android app.

## Important limitations
- No model weights are included. They are large and must be downloaded separately from a trusted model publisher. Choose a model explicitly compatible with MediaPipe LLM Inference on Android. A compact 1B–2B quantized model is a sensible starting point for a phone with 6 GB RAM, but actual speed and memory use vary.
- Importing a random `.gguf` file will not work: this starter expects a compatible MediaPipe `.task` model.
- The app source has not been built or tested on your particular Vivo Y200e. Android Studio/Gradle may require dependency or SDK adjustments.
- Online mode requires deploying the `server` folder to a secure HTTPS host and configuring its environment variables. Do not put an API key in the Android app.
- The app currently keeps chat only in memory during the session; durable encrypted chat history, account sync, privacy controls, and production hardening are not included yet.
- Speech recognition availability depends on Android speech services and may use the device's configured recognition provider.

## Build the Android app
1. On a computer, install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Build > Build APK(s), then install the generated APK on your phone.
4. In LISA, tap IMPORT MODEL and select a compatible `.task` model file.
5. To enable online mode, deploy the Node server, set `AI_BASE_URL`, `AI_API_KEY`, and `AI_MODEL` on the server, then enter the server's HTTPS base URL in ONLINE SERVER SETTINGS.

## Online bridge setup
Inside `server/`:
```bash
npm install
cp .env.example .env
# Edit .env with your provider settings; keep it private.
npm start
```
Use HTTPS in production. Add authentication, rate limits, logging controls, and a privacy policy before sharing the app with others.
