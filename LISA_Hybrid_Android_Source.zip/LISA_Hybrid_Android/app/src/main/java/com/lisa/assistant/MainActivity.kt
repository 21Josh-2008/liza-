package com.lisa.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LisaScreen() }
    }
}

data class ChatLine(val text: String, val fromUser: Boolean)

@Composable
fun LisaScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("lisa", Context.MODE_PRIVATE) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "") ?: "") }
    var draft by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Offline model not installed") }
    var busy by remember { mutableStateOf(false) }
    var lines by remember { mutableStateOf(listOf(ChatLine("Hi! I'm LISA. We can chat online or offline once an offline model is added.", false))) }
    var engine by remember { mutableStateOf<LlmInference?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    val bg = Color(0xFF090B18)
    val accent = Color(0xFF9B78FF)

    DisposableEffect(Unit) {
        val speaker = TextToSpeech(context) { }
        speaker.language = Locale.US
        tts = speaker
        onDispose { speaker.shutdown(); engine?.close() }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val modelFile = withContext(Dispatchers.IO) {
                        val out = File(context.filesDir, "lisa-model.task")
                        context.contentResolver.openInputStream(uri)!!.use { input -> out.outputStream().use(input::copyTo) }
                        out
                    }
                    engine?.close()
                    engine = withContext(Dispatchers.IO) {
                        val options = LlmInference.LlmInferenceOptions.builder()
                            .setModelPath(modelFile.absolutePath)
                            .setMaxTokens(512)
                            .build()
                        LlmInference.createFromOptions(context, options)
                    }
                    status = "Offline model ready"
                } catch (e: Exception) {
                    status = "Could not load model: ${e.message ?: "check model format"}"
                }
            }
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) draft = spoken
        }
    }

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    suspend fun onlineReply(message: String): String = withContext(Dispatchers.IO) {
        if (endpoint.isBlank()) throw IllegalStateException("Add your secure LISA server URL in Settings first")
        val json = JSONObject().put("message", message).toString()
        val body = json.toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url(endpoint.trimEnd('/') + "/chat").post(body).build()
        OkHttpClient().newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Online server returned ${response.code}")
            JSONObject(response.body?.string() ?: "{}").optString("reply", "I couldn't form a reply just now.")
        }
    }

    suspend fun offlineReply(message: String): String = withContext(Dispatchers.IO) {
        val local = engine ?: throw IllegalStateException("Import a compatible offline .task model first")
        local.generateResponse("You are LISA, a warm, friendly, helpful assistant. Keep replies natural and clear.\nUser: $message\nLISA:")
    }

    fun send() {
        val message = draft.trim()
        if (message.isEmpty() || busy) return
        draft = ""
        lines = lines + ChatLine(message, true)
        busy = true
        scope.launch {
            val reply = try {
                if (isOnline()) {
                    try { onlineReply(message) } catch (_: Exception) { offlineReply(message) }
                } else offlineReply(message)
            } catch (e: Exception) {
                "I can't reply yet: ${e.message ?: "please check the setup"}. You can still open Settings to connect the online server or import an offline model."
            }
            lines = lines + ChatLine(reply, false)
            tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "lisa-reply")
            busy = false
            status = if (isOnline()) "Internet available · online first" else "Offline mode"
        }
    }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17132D), bg, bg))).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("LISA", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(status, color = Color(0xFFB9AEDC), fontSize = 12.sp)
            }
            TextButton(onClick = { modelPicker.launch(arrayOf("*/*")) }) { Text("IMPORT MODEL", color = accent) }
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF111426), RoundedCornerShape(22.dp)).padding(12.dp)) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(lines) { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                        Text(line.text, color = Color.White, modifier = Modifier.widthIn(max = 300.dp).background(if (line.fromUser) Color(0xFF5942A8) else Color(0xFF24283D), RoundedCornerShape(16.dp)).padding(12.dp))
                    }
                }
                if (busy) item { Text("LISA is thinking…", color = Color.LightGray) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message LISA…") }, maxLines = 4, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = accent, unfocusedBorderColor = Color(0xFF55516A), cursorColor = accent))
            Spacer(Modifier.width(6.dp))
            Button(onClick = { send() }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Send") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                }
                try { speechLauncher.launch(intent) } catch (_: Exception) { status = "Speech input is not available on this device" }
            }) { Text("VOICE INPUT", color = accent) }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { lines = listOf(ChatLine("Hi! I'm LISA. What would you like to talk about?", false)) }) { Text("NEW CHAT", color = Color.LightGray) }
        }
        var showSettings by remember { mutableStateOf(false) }
        TextButton(onClick = { showSettings = true }) { Text("ONLINE SERVER SETTINGS", color = Color(0xFFB9AEDC)) }
        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("LISA online server") },
            text = { OutlinedTextField(value = endpoint, onValueChange = { endpoint = it }, label = { Text("Server URL ending with no /chat") }, placeholder = { Text("https://your-server.example") }) },
            confirmButton = { TextButton(onClick = { prefs.edit().putString("endpoint", endpoint).apply(); showSettings = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }
}
