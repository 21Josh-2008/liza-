import express from 'express';
const app = express();
app.use(express.json({ limit: '32kb' }));
app.post('/chat', async (req, res) => {
  try {
    const message = String(req.body?.message || '').trim();
    if (!message) return res.status(400).json({ error: 'Message is required' });
    if (!process.env.AI_API_KEY || !process.env.AI_BASE_URL || !process.env.AI_MODEL) {
      return res.status(503).json({ error: 'Online AI is not configured on the server' });
    }
    const upstream = await fetch(`${process.env.AI_BASE_URL.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.AI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.AI_MODEL, messages: [
        { role: 'system', content: 'You are LISA, a friendly, thoughtful, helpful assistant. Be natural, respectful, and clear.' },
        { role: 'user', content: message }
      ] })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(502).json({ error: 'AI provider request failed' });
    res.json({ reply: data.choices?.[0]?.message?.content || 'I could not create a reply.' });
  } catch {
    res.status(500).json({ error: 'Server error' });
  }
});
app.get('/health', (_req, res) => res.json({ ok: true }));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`LISA bridge listening on ${port}`));
